const { Cartas } = require('./model');

class CartasRepository {

    async save(usuario) {
        //salvar cartas
    }
}

module.exports = CartasRepository;